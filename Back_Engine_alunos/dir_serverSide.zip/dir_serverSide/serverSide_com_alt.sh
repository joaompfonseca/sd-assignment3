java -Djava.rmi.server.codebase="file:///home/sd306/test/BackEngine/dir_serverSide/"\
     -Djava.rmi.server.useCodebaseOnly=false\
     -Djava.security.policy=java.policy\
     serverSide.ServerComputeEngine
